# -*- coding: utf-8 -*-
import cv2
import sys
# PyQt5中使用的基本控件都在PyQt5.QtWidgets模块中
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets, Qt
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from startcollect.collect import Ui_Form
from startcollect.test000000 import video

class MyMainForm(QMainWindow, Ui_Form):
    def __init__(self, parent=None):
        super(MyMainForm, self).__init__(parent)
        self.setupUi(self)

        # 添加退出按钮信号和槽,调用close函数,实现退出按钮的功能
        self.pushButton_quit.clicked.connect(self.close)
        #打开文件夹
        self.pushButton_openfile.clicked.connect(self.openfile)
        self.pushButton_start.clicked.connect(self.startvideo)


    def openfile(self):
        openfile_name = QFileDialog.getOpenFileName(self, "选择文件", "./")
    def startvideo(self):
        cap = cv2.VideoCapture(0)
        while True:
            # 从摄像头读取图片
            success, getimage = cap.read()
            # 转为灰度图
            gray = cv2.cvtColor(getimage, cv2.COLOR_BGR2GRAY)
            cv2.imshow("getimage", gray)
            k = cv2.waitKey(1)
            # 通过esc键退出摄像
            if k == 27:
                cv2.destroyAllWindows()
                break
            # 通过s键保存图片，并退出
            elif k == ord("s"):
                cv2.imwrite("C:\\Users\\hp\\Desktop\\recognition\\att_faces\\pic05.jpg", getimage)
                cv2.destroyAllWindows()
                break
        # 关闭摄像头
        cap.release()

if __name__ == "__main__":
    # 固定的，PyQt5程序都需要QApplication对象。sys.argv是命令行参数列表，确保程序可以双击运行
    app = QApplication(sys.argv)
    # 初始化
    myWin = MyMainForm()
    # 将窗口控件显示在屏幕上
    myWin.show()
    # 程序运行，sys.exit方法确保程序完整退出。
    sys.exit(app.exec_())