# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'collect.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(668, 497)
        self.pushButton_openfile = QtWidgets.QPushButton(Form)
        self.pushButton_openfile.setGeometry(QtCore.QRect(100, 70, 151, 61))
        self.pushButton_openfile.setObjectName("pushButton_openfile")
        self.pushButton_clear = QtWidgets.QPushButton(Form)
        self.pushButton_clear.setGeometry(QtCore.QRect(340, 70, 151, 61))
        self.pushButton_clear.setObjectName("pushButton_clear")
        self.pushButton_start = QtWidgets.QPushButton(Form)
        self.pushButton_start.setGeometry(QtCore.QRect(100, 280, 151, 61))
        self.pushButton_start.setObjectName("pushButton_start")
        self.pushButton_quit = QtWidgets.QPushButton(Form)
        self.pushButton_quit.setGeometry(QtCore.QRect(340, 280, 151, 61))
        self.pushButton_quit.setObjectName("pushButton_quit")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton_openfile.setText(_translate("Form", "打开"))
        self.pushButton_clear.setText(_translate("Form", "清空"))
        self.pushButton_start.setText(_translate("Form", "开始检测"))
        self.pushButton_quit.setText(_translate("Form", "退出"))
