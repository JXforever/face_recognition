# -*- coding: utf-8 -*-
import sys
import os.path
# PyQt5中使用的基本控件都在PyQt5.QtWidgets模块中
from PyQt5.QtWidgets import *
from create.create_csv import Ui_Form

class MyMainForm(QMainWindow, Ui_Form):
    def __init__(self, parent=None):
        super(MyMainForm, self).__init__(parent)
        self.setupUi(self)

        self.pushButton_4.clicked.connect(self.close)
        self.pushButton_2.clicked.connect(self.openfile)
        self.pushButton.clicked.connect(self.createcsv)

    def createcsv(self):
        # 生成csv文件
        if __name__ == "__main__":
            BASE_PATH = "C:\\Users\\hp\\Desktop\\recognition\\att_faces"
            SEPARATOR = ";"
            fh = open("C:C:\\Users\\hp\\Desktop\\recognition\\att_faces\\at.txt", 'w')
            label = 0
            for dirname, dirnames, filenames in os.walk(BASE_PATH):
                for subdirname in dirnames:
                    subject_path = os.path.join(dirname, subdirname)
                    for filename in os.listdir(subject_path):
                        abs_path = "%s/%s" % (subject_path, filename)
                        print("%s%s%d" % (abs_path, SEPARATOR, label))
                        fh.write(abs_path + SEPARATOR + str(label) + "\n")
                    label = label + 1
            fh.close()

    def openfile(self):
        openfile_name = QFileDialog.getOpenFileName(self, "选择文件", "C:\\Users\\hp\\Desktop\\recognition\\att_faces\\")



if __name__ == "__main__":
    # 固定的，PyQt5程序都需要QApplication对象。sys.argv是命令行参数列表，确保程序可以双击运行
    app = QApplication(sys.argv)
    # 初始化
    myWin = MyMainForm()
    # 将窗口控件显示在屏幕上
    myWin.show()
    # 程序运行，sys.exit方法确保程序完整退出。
    sys.exit(app.exec_())