import face_recognition
import cv2
import numpy
from playsound import playsound


# 调用笔记本摄像头
cap = cv2.VideoCapture(0)
while True:
    # 从摄像头读取图片
    success, getimage = cap.read()
    # 转为灰度图
    gray = cv2.cvtColor(getimage, cv2.COLOR_BGR2GRAY)
    cv2.imshow("getimage", gray)
    k = cv2.waitKey(1)
    if k == 27:
        # 通过esc键退出摄像
        cv2.destroyAllWindows()
        break
    elif k == ord("s"):
        # 通过s键保存图片，并退出。
        cv2.imwrite("pic000.jpg", getimage)
        cv2.destroyAllWindows()
        break
# 关闭摄像头
cap.release()

know_image = face_recognition.load_image_file("pic01.jpg")
unknow_image = face_recognition.load_image_file("pic000.jpg")

konw_encodings = face_recognition.face_encodings(know_image)[0]
unknow_encodings = face_recognition.face_encodings(unknow_image)[0]

result = face_recognition.compare_faces([konw_encodings],unknow_encodings)

if result[0] == True:
    print("陶铮铭")

else:
    print("查无此人")
    playsound("warningsound.mp3")