import face_recognition
from test.bianlitest import read_path


know_image = face_recognition.load_image_file("collect picture/pic_tzm.jpg")
konw_encodings = face_recognition.face_encodings(know_image)[0]
unknow_encodings = read_path("C:\\Users\\hp\\Desktop\\recognition\\att_faces")

result = face_recognition.compare_faces([konw_encodings],unknow_encodings)
