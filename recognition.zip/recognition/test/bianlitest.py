import cv2
import face_recognition
import os


def read_path(path_name):
    for dir_item in os.listdir(path_name):
        # 从初始路径开始叠加，合并成可识别的操作路径
        full_path = os.path.abspath(os.path.join(path_name, dir_item))

        if os.path.isdir(full_path):  # 如果是文件夹，继续递归调用
            read_path(full_path)
        else:  # 文件
            if dir_item.endswith('.pgm'):
                unknow_image = cv2.imread(full_path)
                unknowimage_encodings = face_recognition.face_encodings(unknow_image)[0]

    return unknowimage_encodings

read_path("C:\\Users\\hp\Desktop\\recognition\\att_faces")